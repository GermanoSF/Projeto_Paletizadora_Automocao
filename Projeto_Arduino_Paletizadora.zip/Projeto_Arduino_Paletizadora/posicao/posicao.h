class Posicao {
private:
  int x;
  int y;
  int z;

public:
  // Construtor padr�o
  Posicao() {}

  // Construtor com par�metros
  Posicao(int xx, int yy, int zz) {
    x = xx;
    y = yy;
    z = zz;
  }

  // Getters e Setters
  int getX() { return x; }
  void setX(int xx) { x = xx; }

  int getY() { return y; }
  void setY(int yy) { y = yy; }

  int getZ() { return z; }
  void setZ(int zz) { z = zz; }
};